GlobalConf = {

    // blueColor: "#1ED760",
    // greyColor: "#282828",
    // purpleColor: "#7C25F8",
    // greenColor:  "#1ED760",
    // darkColor:  "#181818",
    // darkGreyColor:  "#282828",
    // lightGreyColor:  "#AFAFAF",
    // AtomDarkColor:  "#22252B",
    // AtomLighterDarkColor: "#292C36",
    // bodyColor: "#232323",


    // #1ED760 --> rgb(30, 215, 96)

    //
    // Global Stuff
    // Std Conf
    //

    <?php

    if (isset($_GET[ "userId" ]))
    {
        $userId = $_GET[ "userId" ];
    }
    else
    {
        $userId = "patrick";
    }

    echo "userId: \"$userId\",\n";
    // echo "    categorys: " . getConf($userId) . ",\n";

    ?>

    //
    // Categorys
    //

    categorys: {
        "Calendar": "#1ED760",
        "School": "#B36AE2",
        "Privat": "#EC5D57",
        "Work": "#F39019",
    },

    // fontFamily: "Ubuntu, Helvetica, Arial",
    // fontFamily: "Helvetica, Arial",
    fontFamily: "Lato",

    bodyColor: "#292C34",
    headlineColor: "#CC006A",
    // headlineColor2: "#232323",
    headlineColor2: "#ffffff",

    //
    // StdDesign
    //

    std_headline_height: 80,
    std_headline_fontSize: 50,
    std_buttonBar_height: 60,
    std_button_size: 50,
    std_button_color: "#ffffff",
    std_button_mouseover_color: "#CC006A",

    std_input_border: "2px solid #ffffff",
    std_input_color: "#ffffff",

    //
    // Calendar Month
    //

    month_circleSize: 60,
    month_circlefontSize: 20,

    month_headlineFontSize: 20,
    month_headlineHeight: 50,

    month_weekDayHeight: 50,
    month_weekDayBarColor: "#ffffff",
    month_weekfontSize: 20,

    month_weekHeight: 50,
    month_weekPadding: 10,

    month_todayColor: "#232323",
    month_noneMonthColor: "#1f1e1e",
    month_monthColorEvent: "#CC006A",
    month_monthColorNormal: "#232323",
    month_monthFontColor: "#ffffff",
    month_weekDayColor: "#ffffff",
    month_mouseOverColor: "#ffffff",

    //
    // Calendar Month Info
    //

    categorysInfo_eventFontSize: "40px",
    categorysInfo_eventColor: "#7C25F8",

    categorysInfo_categoryPadding: 40,

    categorysInfo_mainCircleSize: 150,
    categorysInfo_mainCircleColor: "#232323",

    categorysInfo_categoryFontSize: "40px",
    categorysInfo_categoryColor: "#ffffff",

    categorysInfo_categoryDefaultCircleSize: 30,
    categorysInfo_categoryPaddingTop: 10,

    //
    // Schedule
    //

    scheduleHeadlineHeight: 50,
    scheduleHeadlineSize: 30,
    scheduleHeadlineColor: "#7C25F8",
    schedulePointColor: "#ffffff",

    //
    // Appointment-Edit
    //

    edit_baseBorder: "3px solid ",
    edit_tileColor: "#232323",
    edit_mainTitleColor: "#CC006A",
    edit_tileBorderColor: "#CC006A",
    edit_tilePointPadding: 10,
    edit_tilefontSize: 40,
    edit_borderRadius: 30,
    edit_mainPointColor: "#ffffff",
    edit_notePointColor: "#5b5b5b",
    edit_fontColor: "#ffffff",

    //
    // Menu
    //

    menu_color: "#232323",

    //
    // Kind
    //

    kind_headlineHeight: 80,
    kind_headfontSize: 50,
    kind_buttonBarHeight: 60,
    kind_buttonSize: 50,

    //
    // add Kind
    //

    addKind_colors: [
        "#70BF41",
        "#F5D328",
        "#F39019",
        "#EC5D57",
        "#B36AE2",
        "#d71ec5",
        "#7e53ee",
        "#19b8d4",
        "#51A7F9",
        "#4036b6",
        "#7FFF00"
    ],

    //
    // DateTime
    //

    dateTime_headlineHeight: 80,
    dateTime_inputHeight: 80
};

// if (GlobalConf.userId == "") GlobalConf.userId = "patrick123";
console.log("userId: " + GlobalConf.userId);
// GlobalConf.dateTime_headlineHeight
