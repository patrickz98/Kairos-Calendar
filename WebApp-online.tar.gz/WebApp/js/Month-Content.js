CalendarMonth = {};

CalendarMonth.updateDate = function(date)
{
    // console.log("CalendarMonth.updateDate: " + date);

    var dayDiv = CalendarMonth.getDateDiv(date);

    CalendarMonth.updateDay(dayDiv, date, false);
    Schedule.update(date);
}

CalendarMonth.getDateDiv = function(date)
{
    var dayDiv = CalendarMonth.dateDiv[ date ];

    return dayDiv;
}

CalendarMonth.getMonthDates = function()
{
    return Object.keys(CalendarMonth.dateDiv);
}

CalendarMonth.updateDay = function(dayDiv, date, outDate)
{
    // console.log("CalendarMonth.updateDay --> " + date + " outDate " + outDate);
    var info = Time.dayInfo(date);

    dayDiv.innerHTML     = date.getDate();
    dayDiv.date          = date;
    dayDiv.month         = info.month;
    dayDiv.year          = info.year;
    dayDiv.color         = GlobalConf.month_monthColorNormal;
    dayDiv.style.color   = GlobalConf.month_weekDayColor;
    dayDiv.style.display = "none";

    if (outDate) return;

    Cricle.changeColor(dayDiv, GlobalConf.month_monthColorNormal);
    dayDiv.style.display = "inline-block";

    if (Time.checkToday(date))
    {
        // Cricle.changeColor(dayDiv, "#ffffff");
        dayDiv.style.color = GlobalConf.month_todayColor;
        dayDiv.style.backgroundColor = "#ffffff";

        return;
    }

    var schedule = DataManager.getDay(dayDiv.date);

    if (schedule.length > 0)
    {
        var color = GlobalConf.month_monthColorEvent;
        dayDiv.color = color;

        var percent = schedule.length / CalendarMonth.eventCount;

        Cricle.changeColor(dayDiv, color);
        WebLibSimple.setOpacity(dayDiv, color, percent);

        return;
    }

    dayDiv.color = GlobalConf.month_monthColorNormal;
    Cricle.changeColor(dayDiv, GlobalConf.month_monthColorNormal);
}

CalendarMonth.getDate = function(month, year, week, day)
{
    var monthInfo = Time.monthInfo(month, year);

    var dayDate  = ((7 * week + day) - monthInfo.month_start_day);
    var dateDate = Time.createDate(dayDate, monthInfo.month, monthInfo.year);
    var isOut    = false;

    if ((week == 0) && (day < monthInfo.month_start_day + 1))
    {
        dayDate  = monthInfo.month_before_count + day - monthInfo.month_start_day;
        dateDate = Time.createDate(dayDate, monthInfo.month_before, monthInfo.year_before);
        isOut    = true;
    }

    if ((week * 7 + day) > monthInfo.min_size)
    {
        dayDate  = day - monthInfo.month_end_day - 1 + ((week - 4) * 7);
        dateDate = Time.createDate(dayDate, monthInfo.month_next, monthInfo.year_next);
        isOut    = true;
    }

    var data   = {};
    data.date  = dateDate;
    data.isOut = isOut;

    return data;
}

CalendarMonth.updateMonth = function(month, year)
{
    CalendarMonth.dateDiv = {};
    var dateDiv = CalendarMonth.dateDiv;

    for (var week = 0; week < 6; week++)
    {
        for (var day = 1; day < 8; day++)
        {
            var index = week + ":" + day;
            var dayDiv = StdMonth.getDayDiv(index);

            var Schedule = CalendarMonth.getDate(month, year, week, day);
            CalendarMonth.updateDay(dayDiv, Schedule.date, Schedule.isOut);

            dateDiv[ Schedule.date ] = dayDiv;
        }
    }
}

CalendarMonth.updateAllDivs = function()
{
    CalendarMonth.eventCount = DataManager.getHighest();
    CalendarMonth.updateMonth(CalendarMonth.month, CalendarMonth.year);
}

CalendarMonth.update = function(month, year)
{
    CalendarMonth.month = month;
    CalendarMonth.year  = year;
    CalendarMonth.eventCount = DataManager.getHighest();

    StdMonth.updateHeadline(month, year);
    CalendarMonth.updateAllDivs();
}

CalendarMonth.init = function(date)
{
    var Schedule = Time.dayInfo(date);

    CalendarMonth.update(Schedule.month, Schedule.year);
}
