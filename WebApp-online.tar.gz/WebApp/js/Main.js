Main = {};

Main.createContainer = function(parent)
{
    Main.containerMonth = WebLibSimple.createDiv(0, 0, 0, "50%", null, parent);
    Main.containerMonth.style.overflow = "hidden";

    Main.containerMonthInfo = WebLibSimple.createDiv(0, "50%", 0, 0, null, parent);
    Main.containerMonthInfo.style.overflow = "hidden";
}

Main.portrait = function()
{
    Main.containerMonth.style.bottom = "50%";
    Main.containerMonth.style.right = "0%";
    Main.containerMonth.style.backgroundColor = "#513385";

    Main.containerMonthInfo.style.top = "50%";
    Main.containerMonthInfo.style.left = "0%";
}

Main.landscape = function()
{
    Main.containerMonth.style.bottom = "0%";
    Main.containerMonth.style.right = "50%";

    Main.containerMonthInfo.style.top = "0%";
    Main.containerMonthInfo.style.left = "50%";
}

Main.resize = function()
{
    var w = window.innerWidth;
    var h = window.innerHeight;

    if (w > h)
    {
        Main.landscape();
    }
    else
    {
        Main.portrait();
    }
}


Main.conf = function()
{
    WebLibSimple.disableSelection(document.body);

    window.ondragstart = function()
    {
        return false;
    }

    var topDiv = StdDesign.createStdDiv(document.body);
    topDiv.style.fontFamily              = GlobalConf.fontFamily;
    topDiv.style.color                   = "#ffffff";
    topDiv.style.overflow                = "hidden";
    topDiv.style.webkitUserSelect        = "none";
    topDiv.style.webkitTapHighlightColor = "rgba(0, 0, 0, 0)";
    topDiv.style.msTouchAction           = "manipulation";
    topDiv.style.touchAction             = "manipulation";

    Spin.createSpin();

    Main.toptopDiv = topDiv;

    var menuWidth = 70;

    Main.containerMenu = WebLibSimple.createDivWidth(0, 0, menuWidth, 0, null, topDiv);
    Main.containerMenu.style.overflow = "hidden";
    Main.containerMenu.style.backgroundColor = GlobalConf.menu_color;

    Menu.init(Main.containerMenu);

    var mover = WebLibSimple.createDiv(menuWidth, 0, 0, 0, null, topDiv);
    Main.mover = mover;

    var contentDiv = WebLibSimple.createDiv(5, 5, 5, 5, null, mover);
    Main.topDiv = contentDiv;

    Main.createContainer(contentDiv);
    Main.resize();

    window.addEventListener("resize", Main.resize);
}

Main.mobileViewport = function()
{
    var meta = WebLibSimple.createAnyAppend("meta", document.head);
    meta.name = "viewport";
    meta.content = "width=device-width, initial-scale=0.5, maximum-scale=1, user-scalable=0";
}

Main.normalViewport = function()
{
    var meta = WebLibSimple.createAnyAppend("meta", document.head);
    meta.name = "viewport";
    meta.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0";
}

Main.checkMobile = function()
{
    var header = navigator.userAgent;

    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(header))
    {
        Main.isMobile = true;
    }
    else
    {
        Main.isMobile = false;
    }

    if(/iPhone|iPad|iPod/i.test(header))
    {
        Main.isIOS = true;
    }
    else
    {
        Main.isIOS = false;
    }

    if(/iPhone|iPod|Mobile|mobile/i.test(header))
    {
        console.log("viewport: mobile");
        Main.mobileViewport();
    }
    else
    {
        console.log("viewport: default");
        Main.normalViewport();
    }

    console.log("Mobile: " + Main.isMobile);
    console.log("iOS: " + Main.isIOS);
    console.log("Header: " + JSON.stringify(header));
}

Main.setHammer = function(parent)
{
    var hammertime = new Hammer(parent);
    hammertime.on("swipe", function(event)
    {
        if (event.isFinal)
        {
            var int = event.deltaX;

            if (int > 200)
            {
                StdMonth.changeMonth("before");
            }

            if (int < -200)
            {
                StdMonth.changeMonth("next");
            }
        }
    });
}

Main.setup = function()
{
    var monthDiv = StdMonth.init(Main.containerMonth);
    Main.setHammer(monthDiv);

    var infoDiv = CategorysInfo.init(Main.containerMonthInfo);

    var scheduleDiv = Schedule.init(new Date(), Main.containerMonthInfo);
    scheduleDiv.style.display = "none";

    Menu.init();

    Main.fixInfoDay = false;

    var mouseOver = function()
    {
        scheduleDiv.style.display = "inline-block";
    }

    var mouseOut = function()
    {
        if (! Main.fixInfoDay)
        {
            scheduleDiv.style.display = "none";
        }
    }

    monthDiv.content.addEventListener("mouseover", mouseOver);
    monthDiv.content.addEventListener("mouseout",  mouseOut);
}

Main.finishedLoading = function(data)
{
    console.log("finished loading");

    Spin.nukeSpin();

    DataManager.parseDatabaseJson(data);

    var today = Time.dayInfo(new Date());

    DataManager.setMonth(today.month, today.year);
}

Main.main = function()
{
    Main.checkMobile();
    Main.conf();
    Main.setup();

    Mongo.getAll(GlobalConf.userId, "Main.finishedLoading");
}

Main.main();
