Schedule = {};

Schedule.updateHeadline = function(title)
{
    var title = Time.getDateTranzlation(title);
    Schedule.topDiv.setHeadline(title);
}

Schedule.createSchedule = function()
{
    var box = WebLibSimple.createDiv(0, 0, 0, 0, null, Schedule.topDiv.content);
    box.style.overflow = "auto";

    Schedule.scheduleBox = box;
}

Schedule.createMain = function(title, parent)
{
    var span = WebLibSimple.createAnyAppend("span", parent);
    span.style.fontSize = "20px";
    span.style.color = "#ffffff";
    // span.style.lineHeight = "10px";
    // span.style.paddingTop = "10px";
    // span.style.marginTop = "2px";
    // span.style.backgroundColor = "#ff00ff";
    span.innerHTML = title;

    return span;
}

Schedule.createNote = function(title, parent)
{
    var span = Schedule.createMain(title, parent);
    span.style.color = GlobalConf.headlineColor2;
    // span.style.fontStyle = "italic";

    return span;
}

Schedule.mouseOver = function(elem, categoryColor)
{
    var mouseOver = function()
    {
        // elem.style.color = categoryColor;
        // elem.style.fontWeight = "900";
    }

    var mouseOut = function()
    {
        // elem.style.color = "#ffffff";
        // elem.style.fontWeight = "100";
    }

    elem.addEventListener("mouseover", mouseOver);
    elem.addEventListener("mouseout",  mouseOut);
}

Schedule.click = function(elem, data)
{
    elem.onclick = function()
    {
        // console.log(data[ "Title" ]);
        console.log("Clicked: " + JSON.stringify(data));

        AppointmentEditor.init(data, Main.topDiv);
    }
}

Schedule.createEvent = function(index, data, box)
{
    var categorys = GlobalConf.categorys;
    var category = data[ "Kind" ];
    var categoryColor = categorys[ category ];

    var paddingTop = 20;
    var tagHeight = 80;

    var loopWidth = 40;
    var loopPaddingFix = -12;
    var loopTextWeight = "300";

    var titleFontSize = 30;
    var titleColor = "#ffffff";

    var top = (paddingTop + tagHeight) * index;
    var tagDiv = WebLibSimple.createDivHeight(0, top, 0, tagHeight, null, box);
    tagDiv.style.overflow = "hidden";
    tagDiv.style.cursor = "pointer";

    Schedule.click(tagDiv, data);

    var createLoopSpan = function(loopChar, align, left, right)
    {
        var loop = WebLibSimple.createAnyAppend("span", tagDiv);
        loop.style.position = "absolute";
        loop.style.left     = left;
        loop.style.top      = loopPaddingFix + "px";
        loop.style.right    = right;
        loop.style.width    = loopWidth + "px";

        loop.style.color      = categoryColor;
        loop.style.fontSize   = tagHeight + "px";
        loop.style.fontWeight = loopTextWeight;
        loop.style.textAlign  = align;

        loop.innerHTML = loopChar;

        return loop
    }

    var loop = createLoopSpan("{", "left", "0px", null);
    var loop = createLoopSpan("}", "right", null, "0px");

    var content = WebLibSimple.createDiv(loopWidth, 0, loopWidth, 0, null, tagDiv);

    var title = WebLibSimple.createDiv(0, 0, "50%", 0, null, content);
    title.style.fontSize = titleFontSize + "px";
    title.style.lineHeight = tagHeight + "px";
    title.style.color = titleColor;
    title.innerHTML = data[ "Title" ];

    var date = WebLibSimple.createDiv("50%", 0, 0, 0, null, content);
    date.style.fontSize = (tagHeight / 4) + "px";
    date.style.lineHeight = (tagHeight / 2) + "px";
    date.style.color = GlobalConf.headlineColor2;
    date.style.textAlign = "right";

    var subHeight = tagHeight / 2;

    var startDiv = WebLibSimple.createDivHeight(0,         0, 0, subHeight, null, date);
    var endDiv   = WebLibSimple.createDivHeight(0, subHeight, 0, subHeight, null, date);

    var start = data[ "Start" ];
    var end   = data[  "End"  ];

    var startDate = Time.getEventDayDate(start).toISOString();
    var endDate   = Time.getEventDayDate(end).toISOString();

    var startTime = Time.getTimeTranzlation(start);
    var endTime   = Time.getTimeTranzlation(end);

    if (startDate != endDate)
    {
        Schedule.createNote(Time.getDateTranzlation(startDate) + " - ", startDiv);
        Schedule.createMain(startTime, startDiv);

        Schedule.createNote(Time.getDateTranzlation(endDate) + " - ", endDiv);
        Schedule.createMain(endTime, endDiv);
    }
    else
    {
        Schedule.createMain(startTime, startDiv);
        Schedule.createMain(endTime, endDiv);
    }
}

Schedule.createNoneDiv = function(parent)
{
    var div = WebLibSimple.createAnyAppend("div", parent);
    div.style.color      = GlobalConf.headlineColor2;
    div.style.fontSize   = GlobalConf.month_headlineFontSize + "px";
    div.style.textAlign  = "center";
    // div.style.paddingTop = "200px";
    div.style.paddingTop = "45%";
    // div.style.top = "33%";
    div.style.fontSize   = GlobalConf.std_headline_fontSize + "px";
    div.style.position   = "relative";
    div.innerHTML        = "None";
}

// Schedule.sortByStart = function(schedule)
// {
//     for (var event in schedule)
//     {
//         event[ "Start" ] = new Date(event[ "Start" ]).getTime
//     }
//
// }

Schedule.updateSchedule = function(schedule)
{
    if (! Schedule.scheduleBox)
    {
        Schedule.createSchedule();
    }

    var box = Schedule.scheduleBox;
    box.innerHTML = "";

    var createdEvents = 0;

    for (var event in schedule)
    {
        var event = schedule[ event ];

        if ((Main.showCategory != null) && (event[ "Kind" ] != Main.showCategory)) continue;

        Schedule.createEvent(createdEvents, event, box);
        createdEvents++;
    }

    if (createdEvents == 0)
    {
        Schedule.createNoneDiv(box);
    }
}

Schedule.back = function()
{
    StdMonth.disableSelections();

    Schedule.topDiv.style.display = "none";
    Main.fixInfoDay = false;
}

Schedule.add = function()
{
    var date = Schedule.date;

    var data =
    {
        "id": null,
        "Title": "New",
        "Place": "",
        "Kind": "Calendar",
        "All-Day": false,
        "Start": date,
        "End": date,
        "Repeat": "",
        "Available": false,
        "Notes": ""
    };

    AppointmentEditor.init(data, Main.topDiv);
}

Schedule.createButtons = function(parent)
{
    parent.createButton("<", Schedule.back);
    parent.createButton("+", Schedule.add);
}

Schedule.update = function(date)
{
    Schedule.date = date;

    var schedule = DataManager.getDay(date);

    // console.log("Schedule.update(" + JSON.stringify(date) + ")");

    Schedule.updateHeadline(date);
    Schedule.updateSchedule(schedule);
}

Schedule.updateInnerSchedule = function()
{
    var schedule = DataManager.getDay(Schedule.date);
    Schedule.updateSchedule(schedule);
}

Schedule.reconfHeadline = function(parent)
{
    parent.headline.style.fontSize   = GlobalConf.scheduleHeadlineSize   + "px";
    parent.headline.style.lineHeight = GlobalConf.scheduleHeadlineHeight + "px";
    parent.headline.style.height     = GlobalConf.scheduleHeadlineHeight + "px";
    parent.headline.style.color      = GlobalConf.scheduleHeadlineColor;

    parent.content.style.top = GlobalConf.scheduleHeadlineHeight + "px";
}

Schedule.init = function(date, parent)
{
    var div = StdDesign.createStd(parent);
    Schedule.topDiv = div;

    Schedule.reconfHeadline(div);
    Schedule.createButtons(div);

    return div;
}
