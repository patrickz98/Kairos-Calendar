Menu = {};

Menu.createHeadline = function()
{
    var height = GlobalConf.std_headline_height;

    var div = WebLibSimple.createDivHeight(0, 0, 0, height, null, Menu.topDiv);
    div.style.fontSize = GlobalConf.std_headline_fontSize + "px";
    div.style.lineHeight = height + "px";
    div.style.color = GlobalConf.std_button_color;
    div.style.textAlign = "center";
    // div.style.borderBottom = "1px solid #ffffff";

    div.innerHTML = "Menu";
}

Menu.createEntry = function(index, json, parent)
{
    var height = 40;
    var paddingTop = 15;
    var top = (height + paddingTop) * index;

    var paddingLR = 15;
    var div = WebLibSimple.createDivHeight(paddingLR, top, paddingLR, height, null, parent);
    // div.style.backgroundColor = "#58b931";
    div.style.backgroundColor = "#ac70d6";
    div.style.cursor = "pointer";
    div.onclick = json.click;

    var center = WebLibSimple.createAnyAppend("center", div);

    var container = WebLibSimple.createAnyAppend("div", center);
    container.style.textAlign = "left";

    var img = Cricle.createImgCircle(height, "#ffffff", json.icon, container);

    var title = WebLibSimple.createAnyAppend("span", container);
    title.style.paddingLeft = "30px";
    title.innerHTML = json[ "name" ];
}

Menu.createContent = function()
{
    var top    = GlobalConf.std_headline_height + 5;
    var bottom = GlobalConf.std_buttonBar_height;

    var fontSize = 20;
    var height = 40;

    var div = WebLibSimple.createDiv(0, top, 0, bottom, null, Menu.topDiv);
    div.style.overflow = "auto";
    div.style.fontSize = fontSize + "px";
    div.style.lineHeight = height + "px";
    div.style.color = "#ffffff";

    var json = [
        {
            "name": "Search",
            "icon": "img/serach-w.png",
            "click": MenuEventHandler.openSearch
        },
        {
            "name": "Search",
            "icon": "img/serach-w.png",
            "click": MenuEventHandler.openSearch
        },
        {
            "name": "Scan",
            "icon": "img/scan-w.png",
            "click": MenuEventHandler.openScan
        },
        {
            "name": "Config",
            "icon": "img/config-w.png",
            "click": MenuEventHandler.openConf
        },
        {
            "name": "Upload",
            "icon": "img/upload-w.png",
            "click": MenuEventHandler.openUploader
        }
    ];

    for (var index in json)
    {
        var data = json[ index ];
        Menu.createEntry(index, data, div);
    }
}

Menu.createButtonBar = function()
{
    var height = GlobalConf.std_buttonBar_height;
    var parent = Menu.topDiv;

    var buttonBar = StdDesign.createStdButtonBar(height, parent);

    buttonBar.style.backgroundColor  = null;

    buttonBar.createButton("X", Menu.closeAnimation);
}

Menu.setup = function()
{
    var div = WebLibSimple.createDivWidth("100%", 0, "30%", 0, null, Main.toptopDiv)
    // div.style.backgroundColor = "#7C25F8";
    div.style.backgroundColor = GlobalConf.menu_color;

    Menu.topDiv = div;

    // Menu.createHeadline();
    // Menu.createContent();
    // Menu.createButtonBar();
}

Menu.openAnimation = function()
{
    if (Menu.animationStatus > 0)
    {
        Menu.closeAnimation();
        return;
    }

    Menu.animationStatus = 0;

    var open = function()
    {
        if (Menu.animationStatus < 30)
        {
            Main.mover.style.left = (Menu.animationStatus * -1) + "%";
            Main.mover.style.right = Menu.animationStatus + "%";

            Menu.topDiv.style.left = (100 - Menu.animationStatus) + "%";

            Menu.animationStatus = Menu.animationStatus + 4;

            setTimeout(open, 40);
        }
    }

    open();
}

Menu.closeAnimation = function()
{
    Menu.animationStatus = Menu.animationStatus - 4;

    var close = function()
    {
        if (Menu.animationStatus > -1)
        {
            Main.mover.style.left = (Menu.animationStatus * -1) + "%";
            Main.mover.style.right = Menu.animationStatus + "%";

            Menu.topDiv.style.left = (100 - Menu.animationStatus) + "%";

            Menu.animationStatus = Menu.animationStatus - 4;

            setTimeout(close, 40);
        }
    }

    close();
}

Menu.createMenuPoint = function(index, data, parent)
{
    var menuWidth = 70;
    var size = 40;
    var paddingTop = 40;
    var left = (menuWidth - size) / 2;

    var top = (size + paddingTop) * index + paddingTop;

    var img = WebLibSimple.createImgWidHei(left, top, size, size, null, parent);

    img.style.cursor = "pointer";

    img.src = data.icon;
    img.onclick = data.click;

    var touchstart = function()
    {
        console.log("touchstart");
        img.style.opacity = "0.5";
    }

    var touchend = function()
    {
        console.log("touchend");
        var tmp = function()
        {
            img.style.opacity = "1.0";
        }

        setTimeout(tmp, 100);
    }

    img.addEventListener("touchstart", touchstart);
    img.addEventListener("touchend",   touchend);
}

Menu.openMenu = function(parent)
{
    Android.showToast("Menu");
}

Menu.init = function(parent)
{
    var json = [
        {
            "icon": "img/menu-w.png",
            "click": Menu.openMenu
        },
        {
            "icon": "img/serach-w.png",
            "click": MenuEventHandler.openSearch
        },
        {
            "icon": "img/scan-w.png",
            "click": MenuEventHandler.openScan
        },
        {
            "icon": "img/config-w.png",
            "click": MenuEventHandler.openConf
        },
        {
            "icon": "img/upload-w.png",
            "click": MenuEventHandler.openUploader
        },
        {
            "icon": "img/reload-w.png",
            "click": MenuEventHandler.reload
        }
    ];

    for (var index in json)
    {
        var data = json[ index ];
        Menu.createMenuPoint(index, data, parent);
    }
}
