Text = {};

Text.update = function()
{
    var text = Text.input.input.value;

    Text.input.input.blur();

    AppointmentEditor.update(Text.key, text);

    Text.topDiv.style.innerHTML = "";
    Text.topDiv.style.display = "none";
}

Text.createButtons = function(parent)
{
    parent.createButton("<", parent.nuke);
    parent.createButton("Ok", Text.update);
}

Text.createInput = function(oldTxt, parent)
{
    var height = 100;
    var placeholder = "type!";

    var input = StdDesign.createInput(height, placeholder, parent);

    input.input.onkeypress = function(e)
    {
        if (e.keyCode == 13)
        {
            Text.update();
        }
    }

    if (oldTxt)
    {
        input.input.value = oldTxt;
    }

    Text.input = input;
}

Text.init = function(title, oldTxt, parent)
{
    var div = StdDesign.createStd(parent);
    Text.topDiv = div;
    Text.key    = title;

    div.setHeadline(title);
    Text.createInput(oldTxt, div.content);
    Text.createButtons(div);
}
