AddKind = {};

AddKind.addNew = function()
{
    Kind.add(AddKind.input.value, AddKind.color);
    AddKind.back();
}

AddKind.select = function(event)
{
    var target = event.target;

    for (var colorDiv in AddKind.colorDivs)
    {
        var div = AddKind.colorDivs[ colorDiv ];
        div.selected = false;
        div.style.border = "2px solid " + div.color;
    }

    target.selected = true;
    target.style.border = "2px solid #ffffff";

    AddKind.color = target.color;

    console.log("--> selected: " + target.color);
}

AddKind.mouseOver = function(elem)
{
    elem.addEventListener("mouseover", mouseOver);
    elem.addEventListener("mouseout",  mouseOut);

    function mouseOver()
    {
        elem.style.border = "2px solid #ffffff";
    }

    function mouseOut()
    {
        if (! elem.selected)
        {
            elem.style.border = "2px solid " + elem.color;
        }
    }
}

AddKind.createColorDiv = function(color, size, paddingLR, parent, eventFunct)
{
    var border = "2px solid " + color;

    var paddingDiv = WebLibSimple.createAnyAppend("div", parent);
    paddingDiv.style.display      = "inline-block";
    paddingDiv.style.width        = (size + paddingLR * 2) + "px";
    paddingDiv.style.paddingLeft  = paddingLR + "px";
    paddingDiv.style.paddingRight = paddingLR + "px";

    var button = Cricle.createBorderCircle("", size, color, border, paddingDiv, eventFunct);
    button.style.left       = paddingLR + "px";
    button.color            = color;
    button.selected         = false;

    AddKind.mouseOver(button);

    WebLibSimple.setBGColor(button, color);

    return button;
}

AddKind.createColorPicker = function(parent)
{
    var top = 100 + 50;
    var height = 100;
    var div = WebLibSimple.createDivHeight(0, top, 0, height, null, parent);

    var center = WebLibSimple.createAnyAppend("center", div);

    AddKind.colorDivs = [];
    var colors = GlobalConf.addKind_colors;

    for (var index in colors)
    {
        var color = colors[ index ];
        var colorDiv = AddKind.createColorDiv(color, 50, 10, center, AddKind.select);
        AddKind.colorDivs.push(colorDiv);
    }
}

AddKind.createInput = function(parent)
{
    var border = 20;
    var borderDiv = WebLibSimple.createDiv(0, border, 0, border, null, parent);
    borderDiv.style.overflow = "hidden";

    var div = StdDesign.createInput(100, "new kind", borderDiv);

    AddKind.input = div.input;

    AddKind.createColorPicker(borderDiv);
}


AddKind.back = function()
{
    AddKind.topDiv.style.innerHTML = "";
    AddKind.topDiv.style.display = "none";
}

AddKind.createButtons = function(parent)
{
    parent.createButton("X",  parent.nuke);
    parent.createButton("Ok", AddKind.addNew);
}

AddKind.init = function(parent)
{
    var div = StdDesign.createStd(parent);

    div.setHeadline("Add kind");
    AddKind.createInput(div.content);
    AddKind.createButtons(div);

    AddKind.topDiv = div;
}
