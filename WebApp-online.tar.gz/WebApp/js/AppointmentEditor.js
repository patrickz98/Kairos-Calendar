AppointmentEditor = {};

AppointmentEditor.update = function(key, value)
{
    AppointmentEditor.data[ key ] = value;

    var box = AppointmentEditor.boxByKey[ key ];

    if (value === "")
    {
        value = "-";
    }

    box.valueDiv.innerHTML = value;
    box.value = value;

    if (key == "Kind")
    {
        box.borderColor = GlobalConf.categorys[ value ];
    }

    if (key == "Start" || key == "End")
    {
        box.valueDiv.innerHTML = Time.getDateTimeTranzlation(value);
    }
}

AppointmentEditor.nuke = function()
{
    Schedule.updateInnerSchedule();
    CalendarMonth.updateAllDivs();

    AppointmentEditor.topDiv.style.innerHTML = "";
    AppointmentEditor.topDiv.style.display = "none";
}

AppointmentEditor.delete = function()
{
    DataManager.delete(AppointmentEditor.data);
    AppointmentEditor.nuke();
}

AppointmentEditor.commit = function()
{
    var doneLoading = function()
    {
        AppointmentEditor.nuke();
    }

    DataManager.commit(AppointmentEditor.data, doneLoading);
}

AppointmentEditor.openQr = function()
{
    var doneLoading = function(id)
    {
        var title = AppointmentEditor.data[ "Title" ];
        console.log("qr: " + title + " -> " + id);

        var tmpJson = JSON.parse(JSON.stringify(AppointmentEditor.data));
        delete tmpJson[ "id" ];

        Qr.init(title, JSON.stringify(tmpJson), AppointmentEditor.topDiv);
        // Qr.init(title, JSON.stringify(json), AppointmentEditor.topDiv);
        // Qr.init(title, id, AppointmentEditor.topDiv);
    }

    DataManager.commit(AppointmentEditor.data, doneLoading);
}

AppointmentEditor.openKind = function()
{
    Kind.init(AppointmentEditor.data[ "Kind" ], AppointmentEditor.topDiv);
}

AppointmentEditor.openBool = function(event)
{
    var target = event.target;
    if (target.root) target = target.root;

    var preBool = AppointmentEditor.data[ target.key ];

    Bool.init(target.key, preBool, AppointmentEditor.topDiv);
}

AppointmentEditor.openText = function(event)
{
    var target = event.target;
    if (target.root) target = target.root;

    console.log("clicked: key   --> " + target.key);
    console.log("clicked: value --> " + target.value);

    Text.init(target.key, target.value, AppointmentEditor.topDiv);
}

AppointmentEditor.openDateTime = function(event)
{
    var target = event.target;
    if (target.root) target = target.root;

    console.log("clicked: key   --> " + target.key);
    console.log("clicked: value --> " + target.value);
    console.log("all-day: value --> " + AppointmentEditor.data[ "All-Day" ]);

    var allDay = AppointmentEditor.data[ "All-Day" ];

    DateTime.init(target.key, target.value, allDay, AppointmentEditor.topDiv);
}

AppointmentEditor.mouseOver = function(elem)
{
    var baseBorder = GlobalConf.edit_baseBorder;

    var mouseOver = function()
    {
        elem.style.border = baseBorder + elem.borderColor;
    }

    var mouseOut = function()
    {
        elem.style.border = baseBorder + GlobalConf.edit_tileColor;
    }

    if (! Main.isMobile)
    {
        elem.addEventListener("mouseover", mouseOver);
        elem.addEventListener("mouseout",  mouseOut);
    }
    else
    {
        elem.addEventListener("touchstart", mouseOver);
        elem.addEventListener("touchend",   mouseOut);
    }
}

AppointmentEditor.createMainPoint = function(title, parent)
{
    var size = GlobalConf.edit_tilefontSize;

    var span = WebLibSimple.createDivHeight(0, 0, 0, 0, null, parent);
    span.style.top        = null;
    span.style.bottom     = GlobalConf.edit_tilePointPadding + "px";
    span.style.height     = size + "px";
    span.style.fontSize   = (size - 4) + "px";
    span.style.lineHeight = (size - 4) + "px";
    span.style.fontWeight = "900";
    span.style.textAlign  = "center";
    span.style.color      = GlobalConf.edit_mainPointColor;
    span.style.overflow   = "hidden";
    span.innerHTML        = title;

    return span;
}

AppointmentEditor.createNotePoint = function(title, parent)
{
    var span = AppointmentEditor.createMainPoint(title, parent);
    span.style.top        = GlobalConf.edit_tilePointPadding + "px";
    span.style.bottom     = null;
    span.style.color      = GlobalConf.edit_notePointColor;
    span.style.fontWeight = "100";

    return span;
}

AppointmentEditor.createOptionFields = function(index, parent)
{
    var size   = 100 / 3;
    var left   = size * index;
    var width  = size + "%";
    var margin = 10;
    var bgcolor = GlobalConf.edit_tileColor;

    var div = WebLibSimple.createDivWidth(left + "%", 0, width, 0, null, parent);

    var content = WebLibSimple.createDiv(margin, margin, margin, margin, null, div);
    content.style.borderRadius = GlobalConf.edit_borderRadius + "px";
    content.style.overflow     = "hidden";
    content.style.border       = GlobalConf.edit_baseBorder + bgcolor;
    content.style.cursor       = "pointer";

    WebLibSimple.setBGColor(content, bgcolor);

    var tagBox = WebLibSimple.createDiv(0, 0, 0, "50%", null, content);
    var tagDiv = AppointmentEditor.createMainPoint("title", tagBox);

    var valueBox = WebLibSimple.createDiv(0, "50%", 0, 0, null, content);
    var valueDiv = AppointmentEditor.createNotePoint("title", valueBox);

    tagBox.root   = content;
    tagDiv.root   = content;
    valueBox.root = content;
    valueDiv.root = content;

    content.tagDiv = tagDiv;
    content.valueDiv = valueDiv;

    AppointmentEditor.mouseOver(content);

    return content;
}

AppointmentEditor.createOptionLine = function(index, parent)
{
    var size   = 100 / 3;
    var top    = size * index;
    var height = size + "%";

    var topDiv = WebLibSimple.createDivHeight(0, top + "%", 0, height, null, parent);

    for (var inx = 0; inx < 3; inx++)
    {
        var optionBoxe = AppointmentEditor.createOptionFields(inx, topDiv);

        var optIndex = index + ":" + inx;
        AppointmentEditor.optionBoxes[ optIndex ] = optionBoxe;
    }
}

AppointmentEditor.createOptions = function(bottom, topDiv)
{
    var topDiv = WebLibSimple.createDiv(0, 0, 0, bottom, null, topDiv);

    var padding = 20;
    var paddingDiv = WebLibSimple.createDiv(padding, 0, padding, 0, null, topDiv);
    // WebLibSimple.setBGColor(paddingDiv, "#203dd4");

    AppointmentEditor.optionBoxes = {};

    for (var inx = 0; inx < 3; inx++)
    {
        AppointmentEditor.createOptionLine(inx, paddingDiv);
    }

    var data = AppointmentEditor.data;
    var keys = AppointmentEditor.dataKeys;

    AppointmentEditor.boxByKey = [];

    var inz = 0;

    for (var inx = 0; inx < 3; inx++)
    {
        for (var iny = 0; iny < 3; iny++)
        {
            var index       = inx + ":" + iny;
            var box         = AppointmentEditor.optionBoxes[ index ];
            box.borderColor = GlobalConf.edit_tileBorderColor;
            box.onclick     = AppointmentEditor.openText;

            var key = keys[ inz ];
            var value = data[ key ];

            box.key = key;
            box.value = value;

            AppointmentEditor.boxByKey[ key ] = box;

            if (value === "")
            {
                value = "-";
            }

            box.tagDiv.innerHTML = key;
            box.valueDiv.innerHTML = value;

            if (key == "Title")
            {
                // var color = GlobalConf.categorys[ data[ "Kind" ] ];
                box.valueDiv.style.color = GlobalConf.edit_mainTitleColor;
            }

            if (key == "Kind")
            {
                var color = GlobalConf.categorys[ data[ "Kind" ] ];
                box.borderColor = color;
                box.onclick = AppointmentEditor.openKind;
            }

            if (key == "All-Day" || key == "Available")
            {
                box.onclick = AppointmentEditor.openBool;
            }

            if (key == "Start" || key == "End")
            {
                box.valueDiv.innerHTML = Time.getDateTimeTranzlation(data[ key ]);
                box.onclick = AppointmentEditor.openDateTime;
            }

            inz++;
        }
    }
}

AppointmentEditor.createButtonBar = function(height, parent)
{
    var div = StdDesign.createStdButtonBar(height, parent);

    div.createButton("Ok", AppointmentEditor.commit);
    div.createButton("Qr", AppointmentEditor.openQr);
    div.createButton("X",  AppointmentEditor.delete);
}

AppointmentEditor.init = function(data, parent)
{
    var topDiv = StdDesign.createStdDiv(Main.toptopDiv);

    AppointmentEditor.topDiv = topDiv;

    var keys = Object.keys(data);

    if (keys.includes("id")) WebLibSimple.removeValFromArray("id", keys);

    AppointmentEditor.data     = data;
    AppointmentEditor.dataKeys = keys;

    var buttonBarHeight = GlobalConf.std_buttonBar_height;

    AppointmentEditor.createOptions(buttonBarHeight, topDiv);
    AppointmentEditor.createButtonBar(buttonBarHeight, topDiv);
}
