Bool = {};

Bool.setButtonSelected = function(elem, selected)
{
    if (selected)
    {
        WebLibSimple.setBGColor(elem, elem.color);
        elem.style.fontWeight = "900";
    }
    else
    {
        elem.style.background = null;
        elem.style.fontWeight = "100";
    }
}

Bool.selectButton = function(elem)
{
    Bool.setButtonSelected(elem, true);
    elem.selected = true;

    if (elem.value)
    {
        var oppositeButton = Bool.buttonNo;
    }
    else
    {
        var oppositeButton = Bool.buttonYes;
    }

    Bool.setButtonSelected(oppositeButton, false);
    oppositeButton.selected = false;
}

Bool.clicked = function(elem)
{
    elem.onclick = function()
    {
        Bool.selectButton(elem);

        AppointmentEditor.update(Bool.key, elem.value);
    }
}

Bool.mouseOver = function(elem, color)
{
    var mouseOver = function()
    {
        Bool.setButtonSelected(elem, true);
    }

    var mouseOut = function()
    {
        Bool.setButtonSelected(elem, elem.selected);
    }

    if (! Main.isMobile)
    {
        elem.addEventListener("mouseover", mouseOver);
        elem.addEventListener("mouseout",  mouseOut);
    }
    else
    {
        elem.addEventListener("touchstart", mouseOver);
        // elem.addEventListener("touchend", mouseOut);
    }
}

Bool.createButtons = function(parent)
{
    parent.createButton("Ok", parent.nuke);
}

Bool.createOption = function(status, parent, eventFunct)
{
    if (status)
    {
        var title = "Yes";
        var color = "#1ED760";
    }
    else
    {
        var title = "No";
        var color = "#EC5D57";
    }

    var size = 200;
    var paddingLR = 20;
    var fontColor = GlobalConf.edit_fontColor;
    var fontSize = size * 0.35;
    var border = "1px solid " + color;
    var eventFunct = null;

    var paddingDiv = WebLibSimple.createAnyAppend("div", parent);
    paddingDiv.style.display      = "inline-block";
    paddingDiv.style.width        = (size + paddingLR * 2) + "px";
    paddingDiv.style.paddingLeft  = paddingLR + "px";
    paddingDiv.style.paddingRight = paddingLR + "px";

    var button = Cricle.createBorderCircle(title, size, color, border, paddingDiv, eventFunct);
    button.style.fontWeight = "100";
    button.style.left       = paddingLR + "px";
    button.style.cursor     = "pointer";
    button.style.color      = fontColor;
    button.style.fontSize   = fontSize + "px";
    button.color            = color;

    button.value            = status;
    button.selected         = false;

    Bool.mouseOver(button, color);
    Bool.clicked(button);

    return button;
}

Bool.createPicker = function(parent)
{
    var center = WebLibSimple.createAnyAppend("center", parent);

    var eventFunct = null;

    Bool.buttonYes = Bool.createOption(true,  center, eventFunct);
    Bool.buttonNo  = Bool.createOption(false, center, eventFunct);
}

Bool.init = function(title, preBool, parent)
{
    Bool.key = title;

    var div = StdDesign.createStd(parent);

    div.setHeadline(title);
    Bool.createPicker(div.content);
    Bool.createButtons(div);

    // var std = true;

    if (preBool)   Bool.selectButton(Bool.buttonYes);
    if (! preBool) Bool.selectButton(Bool.buttonNo);
}
