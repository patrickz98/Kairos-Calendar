GlobalConf = {

    // blueColor: "#1ED760",
    // greyColor: "#282828",
    // purpleColor: "#7C25F8",
    // greenColor:  "#1ED760",
    // darkColor:  "#181818",
    // darkGreyColor:  "#282828",
    // lightGreyColor:  "#AFAFAF",
    // AtomDarkColor:  "#22252B",
    // AtomLighterDarkColor: "#292C36",
    // bodyColor: "#232323",


    // #1ED760 --> rgb(30, 215, 96)

    //
    // Global Stuff
    // Std Conf
    //

    <?php

    include("../../php/Elastic.php");
    include("../Heimdall/conf.php");

    if (isset($_GET[ "userId" ]))
    {
        $userId = $_GET[ "userId" ];
    }
    else
    {
        $userId = "patrick123";
    }

    echo "userId: \"$userId\",\n";
    // echo "    categorys: " . getConf($userId) . ",\n";

    ?>


    //
    // Categorys
    //

    categorys: {
        "Calendar": "#51A7F9",
        "School":   "#F39019",
        "Privat":   "#EC5D57",
        "Work":     "#B36AE2",
    },

    fontFamily: "Ubuntu, Helvetica, Arial",
    bodyColor: "#ffffff",
    headlineColor: "#7C25F8",
    headlineColor2: "#3D3D3D",

    //
    // StdDesign
    //

    std_headline_height: 80,
    std_headline_fontSize: 50,
    std_buttonBar_height: 60,
    std_button_size: 50,
    std_button_color: "#3D3D3D",
    std_button_mouseover_color: "#7C25F8",

    std_input_border: "2px solid #3D3D3D",
    std_input_color: "#3D3D3D",

    //
    // Calendar Month
    //

    month_circleSize: 60,
    month_circlefontSize: 20,

    month_headlineFontSize: 20,
    month_headlineHeight: 50,

    month_weekDayHeight: 50,
    month_weekDayBarColor: "#3D3D3D",
    month_weekfontSize: 20,

    month_weekHeight: 50,
    month_weekPadding: 10,

    month_noneMonthColor: "#1f1e1e",
    month_monthColorEvent: "#7C25F8",
    month_monthColorNormal: "#8b8b8b",
    month_monthFontColor: "#ffffff",
    month_weekDayColor: "#ffffff",
    month_mouseOverColor: "#a8a8a8",

    //
    // Calendar Month Info
    //

    circleBoxFontSize: "60px",
    circleBoxBorder: "2px solid #3D3D3D",
    circleBoxSize: 200,
    circleBoxDefaultColor: "#3D3D3D",

    //
    // Schedule
    //

    scheduleHeadlineHeight: 50,
    scheduleHeadlineSize: 30,
    scheduleHeadlineColor: "#3D3D3D",
    schedulePointColor: "#3D3D3D",

    //
    // Appointment-Edit
    //

    edit_baseBorder: "3px solid ",
    edit_tileColor: "#939393",
    edit_tileBorderColor: "#7C25F8",
    edit_tilePointPadding: 10,
    edit_tilefontSize: 40,
    edit_borderRadius: 30,

    edit_mainPointColor: "#ffffff",
    edit_notePointColor: "#5b5b5b",

    edit_fontColor: "#3D3D3D",

    //
    // Kind
    //

    kind_headlineHeight: 80,
    kind_headfontSize: 50,
    kind_buttonBarHeight: 60,
    kind_buttonSize: 50,

    //
    // add Kind
    //

    addKind_colors: [
        "#70BF41",
        "#F5D328",
        "#F39019",
        "#EC5D57",
        "#B36AE2",
        "#d71ec5",
        "#7e53ee",
        "#19b8d4",
        "#51A7F9",
        "#4036b6",
        "#7FFF00"
    ],

    //
    // DateTime
    //

    dateTime_headlineHeight: 80,
    dateTime_inputHeight: 80
};

// if (GlobalConf.userId == "") GlobalConf.userId = "patrick123";
console.log("userId: " + GlobalConf.userId);
// GlobalConf.dateTime_headlineHeight
