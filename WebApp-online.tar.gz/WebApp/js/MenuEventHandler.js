MenuEventHandler = {};

MenuEventHandler.openSearch = function()
{
    alert("open search");
    Android.showToast("open search");
}

MenuEventHandler.openScan = function()
{
    // alert("open scan");
    console.log(Android.showToast("open scan"));
    Android.openScanner();
}

MenuEventHandler.openConf = function()
{
    alert("open conf");
    Android.showToast("open conf");
}

MenuEventHandler.openUploader = function()
{
    alert("open uploader");
    Android.showToast("open uploader");
}

MenuEventHandler.reload = function()
{
    alert("reload");
    Android.showToast("reload");
    Android.reload();
}

MenuEventHandler.qrCallback = function(scanResult)
{
    console.log("QR-Code: " + scanResult);

    var data = JSON.parse(scanResult);

    AppointmentEditor.init(data, Main.topDiv);

    // DataManager.commit(data, MenuEventHandler.log);
    // CalendarMonth.updateAllDivs();

    // hack
    // Schedule.updateInnerSchedule();
}

MenuEventHandler.log = function(log)
{
    console.log("log: " + log);
}
