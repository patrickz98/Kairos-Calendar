DateTime = {};

DateTime.update = function()
{
    if (! DateTime.allday)
    {
        var time = DateTime.timeInput.input.value;
        DateTime.timeInput.input.blur();
    }

    var date = DateTime.dateInput.input.value;
    DateTime.dateInput.input.blur();

    var newDate = Time.tranzToDate(date, time);

    AppointmentEditor.update(DateTime.key, newDate);

    DateTime.topDiv.style.innerHTML = "";
    DateTime.topDiv.style.display = "none";
}

DateTime.createButtons = function(parent)
{
    parent.createButton("Ok", DateTime.update);
    parent.createButton("X", parent.nuke);
}

DateTime.createHeadline = function(title, parent)
{
    var height = GlobalConf.dateTime_headlineHeight;

    var div = WebLibSimple.createDivHeight(0, 0, 0, height, null, parent);
    div.style.color      = GlobalConf.headlineColor2;
    div.style.textAlign  = "center";
    div.style.lineHeight = height + "px";
    div.style.position   = "relative";
    div.style.fontSize   = (height * 0.5) + "px";
    div.innerHTML        = title;

    return div;
}

DateTime.createBox = function(title, parent)
{
    var headlineHeight = GlobalConf.dateTime_headlineHeight;
    var inputHeight    = GlobalConf.dateTime_inputHeight;

    var div = WebLibSimple.createAnyAppend("div", parent);
    div.style.height = (headlineHeight + inputHeight + 10) + "px";
    div.style.left   = "0px";
    div.style.right  = "0px";

    DateTime.createHeadline(title, div);

    var box = WebLibSimple.createDivHeight(0, 0, 0, inputHeight + 10, null, div);
    box.style.position = "relative";

    div.box = box;

    return div;
}

DateTime.createTimeInput = function(date, parent)
{
    var div = DateTime.createBox("Time", parent);

    var inputHeight = GlobalConf.dateTime_inputHeight;
    var placeholder = "HH:MM";

    var input = StdDesign.createInput(inputHeight, placeholder, div.box);
    input.input.value = Time.getTimeTranzlation(date);
    // input.input.type = "color";
    // input.input.type = "date";
    // input.input.type = "datetime-local";
    // input.input.type = "month";
    // input.input.type = "week";

    // input.input.type = "time";

    input.style.position = "relative";

    input.input.onkeypress = function(e)
    {
        if (e.keyCode == 13)
        {
            DateTime.dateInput.input.focus();
        }
    }

    DateTime.timeInput = input;

    return input;
}

DateTime.createDateInput = function(date, parent)
{
    var div = DateTime.createBox("Date", parent);

    var inputHeight = GlobalConf.dateTime_inputHeight;
    var placeholder = "DD.MM.YYYY";

    var input = StdDesign.createInput(inputHeight, placeholder, div.box);
    input.input.value = Time.getDateTranzlation(date);
    // input.input.type = "date";
    input.style.position = "relative";

    input.input.onkeypress = function(e)
    {
        if (e.keyCode == 13)
        {
            DateTime.update();
        }
    }

    DateTime.dateInput = input;
}


DateTime.init = function(title, date, allday, parent)
{
    DateTime.key = title;

    var div = StdDesign.createStd(parent);
    DateTime.topDiv = div;

    div.setHeadline(title);

    DateTime.allday = allday;

    if (! allday)
    {
        DateTime.createTimeInput(date, div.content);
    }

    DateTime.createDateInput(date, div.content);
    DateTime.createButtons(div);
}
